# Informatica IICS-CAI Migration Tools

This Project provides set of IICS Asset Transformation Utilities such as:

- Set Process Suspend On Fault Deployment Attributes
- Set Process Tracing Level Attribute
- Move Process to different agent or group
- Move Process from Secure Agent or agent deployment group to Cloud
